export default function RootLayout() {
    return (
        <html lang="pt-br">
        <body>
            
        </body>
        </html>
    )
}